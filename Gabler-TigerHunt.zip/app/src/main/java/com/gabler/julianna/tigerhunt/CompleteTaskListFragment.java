package com.gabler.julianna.tigerhunt;


import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;


public class CompleteTaskListFragment extends Fragment {

    private ListView mListView;

    public static Fragment newInstance()
    {
       return new CompleteTaskListFragment();
    }

    @Override
    public View onCreateView(
        LayoutInflater inflater,
        ViewGroup container,
        Bundle savedInstanceState
    ) {

        View view = inflater.inflate(R.layout.fragment_task_list, container, false);
        mListView = (ListView) view.findViewById(R.id.task_list_view);

        Context context = getActivity().getApplicationContext();

        final ArrayList<Task> taskList = Task.getTasksFromFile("tasks.json", context);
        String[] listItems = new String[taskList.size()];
        Boolean[] isCompleted = new Boolean[taskList.size()];


        for(int i = 0; i < taskList.size(); i++){
            Task task = taskList.get(i);
            listItems[i] = task.title;
            isCompleted[i] = true;
        }

        TaskListItemAdapter adapter = new TaskListItemAdapter(context, listItems, isCompleted);
        mListView.setAdapter(adapter);

        return view;
    }
}
