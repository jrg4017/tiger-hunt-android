package com.gabler.julianna.tigerhunt;


import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class Task {
    public String title;
    public String description;
    public String imageUrl;
    public String instructionUrl;
    public String label;
//    public String points;


    public static ArrayList<Task> getTasksFromFile(String filename, Context context){
        final ArrayList<Task> taskList = new ArrayList<>();

        try {
            // Load data
            String jsonString = loadJsonFromAsset(filename, context);
            JSONObject json = new JSONObject(jsonString);
            JSONArray tasks = json.getJSONArray("tasks");

            // Get Task objects from data
            for(int i = 0; i < tasks.length(); i++){
                Task task = new Task();

                task.title = tasks.getJSONObject(i).getString("title");
                task.description = tasks.getJSONObject(i).getString("description");
                task.imageUrl = tasks.getJSONObject(i).getString("image");
                task.instructionUrl = tasks.getJSONObject(i).getString("url");
                task.label = tasks.getJSONObject(i).getString("dietLabel");

                taskList.add(task);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return taskList;
    }

    private static String loadJsonFromAsset(String filename, Context context) {
        String json = null;

        try {
            InputStream is = context.getAssets().open(filename);
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        }
        catch (java.io.IOException ex) {
            ex.printStackTrace();
            return null;
        }

        return json;
    }
}
