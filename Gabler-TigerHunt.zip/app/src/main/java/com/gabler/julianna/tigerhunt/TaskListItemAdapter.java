package com.gabler.julianna.tigerhunt;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

class TaskListItemAdapter extends BaseAdapter {

    Context context;
    String[] data;
    Boolean[] isCompleted;
    private static LayoutInflater inflater = null;

    public TaskListItemAdapter(Context context, String[] titles, Boolean[] isCompleted) {
        this.context = context;
        this.data = titles;
        this.isCompleted = isCompleted;
        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return data.length;
    }

    @Override
    public Object getItem(int position) {
        return data[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null)
            view = inflater.inflate(R.layout.list_item_task, null);

        ImageView imageView = (ImageView) view.findViewById(R.id.task_list_thumbnail);
        TextView text = (TextView) view.findViewById(R.id.task_list_detail);

//        if (isCompleted[position]) {
//            imageView.setImageDrawable(.ic_completed);
//        } else {
//            imageView.setImageDrawable(R.drawable.ic_incomplete);
//        }


        text.setText(data[position]);

        return view;
    }
}